

  $(document).ready(function(){
$("#login").click(function(){
    $('#myModal').modal('hide');
  });

  $("#signup").click(function(){
    $('#myModal1').modal('hide');
  });
});